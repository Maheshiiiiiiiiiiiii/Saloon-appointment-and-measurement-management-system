package com.my.salonisansu

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.provider.BaseColumns
import com.my.salonisansu.AppoinmentE.Appointment2
import com.my.salonisansu.AppoinmentE.Appointment_id
import com.my.salonisansu.AppoinmentE.customer_id1
import com.my.salonisansu.AppoinmentE.date
import com.my.salonisansu.AppoinmentE.end_time
import com.my.salonisansu.AppoinmentE.service_id3
import com.my.salonisansu.AppoinmentE.stylist_id2
import com.my.salonisansu.CustomerE.Customer
import com.my.salonisansu.CustomerE.Customer_id
import com.my.salonisansu.CustomerE.customer_name
import com.my.salonisansu.CustomerE.email
import com.my.salonisansu.CustomerE.phone_number
import com.my.salonisansu.ServiceEntry.Description
import com.my.salonisansu.ServiceEntry.Price
import com.my.salonisansu.ServiceEntry.Service2
import com.my.salonisansu.ServiceEntry.Service_id
import com.my.salonisansu.ServiceEntry.Service_name
import com.my.salonisansu.StylistsEntry.Email
import com.my.salonisansu.StylistsEntry.Phone_number
import com.my.salonisansu.StylistsEntry.Stylists
import com.my.salonisansu.StylistsEntry.Stylists_id
import com.my.salonisansu.StylistsEntry.Stylists_name
import com.my.salonisansu.measurementE.lineStamp
import com.my.salonisansu.measurementE.measurement
import com.my.salonisansu.measurementE.measurement_id
import com.my.salonisansu.measurementE.metrics_id2
import com.my.salonisansu.measurementE.value1
import com.my.salonisansu.metricsE.description
import com.my.salonisansu.metricsE.metrics
import com.my.salonisansu.metricsE.metrics_id
import com.my.salonisansu.metricsE.metrics_name
import com.my.salonisansu.metricsE.unit
import com.my.salonisansu.userE.password
import com.my.salonisansu.userE.user
import com.my.salonisansu.userE.user_id
import com.my.salonisansu.userE.username
import kotlin.random.Random



class DBHelper(context: Context, factory: SQLiteDatabase.CursorFactory?) :
    SQLiteOpenHelper(context, DATABASE_NAME, factory, DATABASE_VERSION) {

    override fun onCreate(DB: SQLiteDatabase) {
        DB.execSQL(SQL_CREATE_user)
        DB.execSQL(SQL_CREATE_Appointment)
        DB.execSQL(SQL_CREATE_Customer)
        DB.execSQL(SQL_CREATE_Service)
        DB.execSQL(SQL_CREATE_measurement)
        DB.execSQL(SQL_CREATE_metrics)
        DB.execSQL(SQL_CREATE_Stylists)

    }

    override fun onUpgrade(db: SQLiteDatabase, p1: Int, p2: Int) {
        db.execSQL(SQL_DELETE_Service2)
        db.execSQL(SQL_DELETE_user)
        db.execSQL(SQL_DELETE_Appointment2)
        db.execSQL(SQL_DELETE_Customer)
        db.execSQL(SQL_DELETE_measurement)
        db.execSQL(SQL_DELETE_metrics)
        db.execSQL(SQL_DELETE_Stylists)
        onCreate(db)
    }

    fun insert1(username : String, password : String ) {
        val values = ContentValues()
        values.put(user_id1, getAutoId())
        values.put(username1, username)
        values.put(password1, password)

        val db = this.writableDatabase
        db.insert(usertable, null, values)
    }
    fun ServiceInsert(ServiceName : String, description : String, price : String) {
        val values = ContentValues()
        values.put(Service_id, getAutoId())
        values.put(Service_name,ServiceName)
        values.put(Description, description)
        values.put(Price, price)

        val db = this.writableDatabase
        db.insert(Servicetable, null, values)
    }
    fun StylistsInsert(StylistsName : String, Pnumber : String, email : String) {
        val values = ContentValues()
        values.put(Stylists_id, getAutoId())
        values.put(Stylists_name, StylistsName)
        values.put(phone_number1, Pnumber)
        values.put(Email, email)

        val db = this.writableDatabase
        db.insert(Styliststable, null, values)
    }
    fun CustomerInsert(CustomerName : String, pnumber : String, Email : String) {
        val values = ContentValues()
        values.put(Customer_id, getAutoId())
        values.put(customer_name, CustomerName)
        values.put(phone_number2,pnumber)
        values.put(email, Email)

        val db = this.writableDatabase
        db.insert(Customertable, null, values)
    }
    fun Appointmentinsert(customerid : String, stylistid : String, serviceid : String, endtime: String, date2 : String ) {
        val values = ContentValues()
        values.put(Appointment_id, getAutoId())
        values.put(customer_id1, customerid)
        values.put(stylist_id2, stylistid)
        values.put(service_id3, serviceid)
        values.put(end_time, endtime)
        values.put(date, date2)

        val db = this.writableDatabase
        db.insert(Appointmenttable, null, values)
    }
    fun measurementinsert(metrics_id : String, value : String, LineStamp : String) {
        val values = ContentValues()
        values.put(measurement_id, getAutoId())
        values.put(metrics_id2, metrics_id)
        values.put(value1, value)
        values.put(lineStamp, LineStamp)

        val db = this.writableDatabase
        db.insert(measurementtable, null, values)
    }
    fun metricsinsert(metricsname : String, Description : String, unit : String) {
        val values = ContentValues()
        values.put(metrics_id, getAutoId())
        values.put(metrics_name, metricsname)
        values.put(description, Description)
        values.put(unit2, unit)

        val db = this.writableDatabase
        db.insert(metricstable, null, values)
    }

    companion object{
        private const val DATABASE_NAME = "Salon"
        private const val DATABASE_VERSION = 1
        const val usertable = "user"
        const val user_id1 = "user_id"
        const val username1 = "usernameTEXT"
        const val password1 = "passwordTEXT"

        const val Servicetable = "Service"
        const val Service_id = "Service_id"
        const val Service_name = "Service_nameTEXT"
        const val Description = "DescriptionTEXT"
        const val Price= "PriceTEXT"

        const val Appointmenttable = "Appointment"
        const val Appointment_id = "Appointment_id"
        const val customer_id1 = "customer_idTEXT"
        const val stylist_id2 = "stylist_idTEXT"
        const val service_id3= "service_idTEXT"
        const val end_time= "end_timeTEXT"
        const val date= "dateTEXT"

        const val Styliststable = "Stylists"
        const val Stylists_id = "Stylists_id"
        const val Stylists_name = "Stylists_nameTEXT"
        const val phone_number1 = "Phone_numberTEXT"
        const val Email= "EmailTEXT"

        const val Customertable = "Customer"
        const val Customer_id = "Customer_id"
        const val customer_name = "customer_nameTEXT"
        const val phone_number2 = "phone_numberTEXT"
        const val email= "emailTEXT"

        const val metricstable = "metrics"
        const val metrics_id = "metrics_id"
        const val metrics_name = "metrics_nameTEXT"
        const val description = "descriptionTEXT"
        const val unit2= "unitTEXT"

        const val measurementtable = "metrics"
        const val measurement_id = "measurement_id"
        const val metrics_id2 = "metrics_idTEXT"
        const val value1 = "valueTEXT"
        const val lineStamp= "lineStampTEXT"

        fun getAutoId():Int{
            val random = Random as Random
            return random.nextInt(100)}
    }

    public fun getSchedule(): Cursor? {
        //Make database readable
        val db = this.readableDatabase
        val query = "select* from $Appointmenttable"
        return db.rawQuery(query, null)
    }

    public fun deleteItem(id: String){
        val db=writableDatabase
        db.delete(Appointmenttable, Appointment_id + "=" + id, null)
        db.close()

    }
    fun getSelectedData(from:String,to:String): Cursor? {
        val db = this.readableDatabase
        return db.rawQuery("SELECT * FROM user WHERE username = ? AND password = ?",
            arrayOf(from,to))
    }

}

object ServiceEntry : BaseColumns {
        const val Service2 = "Service"
        const val Service_id = "Service_id"
        const val Service_name = "Service_name"
        const val Description = "Description"
        const val Price= "Price"
    }

const val SQL_CREATE_Service =
    "CREATE TABLE $Service2 (" +
            "$Service_id PRIMARY KEY," +
            "${Service_name}TEXT," +
            "${Description}TEXT,"+
            "${Price}TEXT)"


object StylistsEntry : BaseColumns {
    const val Stylists = "Stylists"
    const val Stylists_id = "Stylists_id"
    const val Stylists_name = "Stylists_name"
    const val Phone_number = "Phone_number"
    const val Email= "Email"
}

const val SQL_CREATE_Stylists =
    "CREATE TABLE $Stylists (" +
            "$Stylists_id PRIMARY KEY," +
            "${Stylists_name}TEXT," +
            "${Phone_number}TEXT,"+
            "${Email}TEXT)"

object AppoinmentE : BaseColumns {
    const val Appointment2 = "Appointment"
    const val Appointment_id = "Appointment_id"
    const val customer_id1 = "customer_id"
    const val stylist_id2 = "stylist_id"
    const val service_id3= "service_id"
    const val end_time= "end_time"
    const val date= "date"
}

const val SQL_CREATE_Appointment =
    "CREATE TABLE $Appointment2 (" +
            "${Appointment_id} PRIMARY KEY," +
            "${customer_id1}TEXT," +
            "${stylist_id2}TEXT,"+
            "${service_id3}TEXT,"+
            "${end_time}TEXT,"+
            "${date}TEXT)"

object CustomerE: BaseColumns {
    const val Customer = "Customer"
    const val Customer_id = "Customer_id"
    const val customer_name = "customer_name"
    const val phone_number = "phone_number"
    const val email= "email"
}

const val SQL_CREATE_Customer =
    "CREATE TABLE $Customer (" +
            "${Customer_id} PRIMARY KEY," +
            "${customer_name}TEXT," +
            "${phone_number}TEXT,"+
            "${email}TEXT)"

object metricsE: BaseColumns {
    const val metrics = "metrics"
    const val metrics_id = "metrics_id"
    const val metrics_name = "metrics_name"
    const val description = "description"
    const val unit= "unit"
}

const val SQL_CREATE_metrics =
    "CREATE TABLE $metrics (" +
            "${metrics_id} PRIMARY KEY," +
            "${metrics_name}TEXT," +
            "${description}TEXT,"+
            "${unit}TEXT)"

object measurementE: BaseColumns {
    const val measurement = "metrics"
    const val measurement_id = "Customer_id"
    const val metrics_id2 = "customer_name"
    const val value1 = "value"
    const val lineStamp= "lineStamp"
}

const val SQL_CREATE_measurement =
    "CREATE TABLE $measurement (" +
            "$measurement_id PRIMARY KEY," +
            "${metrics_id2}TEXT," +
            "${value1}TEXT,"+
            "${lineStamp}TEXT)"

object userE: BaseColumns {
    const val user = "user"
    const val user_id = "user_id"
    const val username = "username"
    const val password = "password"
}

const val SQL_CREATE_user =
    "CREATE TABLE $user (" +
            "$user_id PRIMARY KEY," +
            "${username}TEXT," +
            "${password}TEXT)"

const val SQL_DELETE_Service2 = "DROP TABLE IF EXISTS $Service2"
const val SQL_DELETE_user = "DROP TABLE IF EXISTS $user"
const val SQL_DELETE_measurement = "DROP TABLE IF EXISTS $measurement"
const val SQL_DELETE_metrics = "DROP TABLE IF EXISTS $metrics"
const val SQL_DELETE_Customer = "DROP TABLE IF EXISTS $Customer"
const val SQL_DELETE_Appointment2 = "DROP TABLE IF EXISTS $Appointment2"
const val SQL_DELETE_Stylists = "DROP TABLE IF EXISTS $Stylists"

