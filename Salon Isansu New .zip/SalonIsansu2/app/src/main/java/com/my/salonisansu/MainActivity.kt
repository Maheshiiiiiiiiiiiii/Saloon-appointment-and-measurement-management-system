package com.my.salonisansu

import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val db=DBHelper(this,null)

        val usernameEditText = findViewById<EditText>(R.id.txtusername)
        val passwordEditText = findViewById<EditText>(R.id.txtpassword)
        val loginButton = findViewById<Button>(R.id.btnlogin)
        val registerButton = findViewById<Button>(R.id.btnregister)
        val rdbsalon = findViewById<RadioButton>(R.id.rdbsalon)
        val rdbtailor = findViewById<RadioButton>(R.id.rdbtailor)


        loginButton.setOnClickListener {
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()

            if (username.isNotEmpty() && password.isNotEmpty()){
                if (rdbsalon.isChecked){
                    val intent = Intent(this, ScheduleAppointment::class.java)
                    intent.putExtra("KEY_username", username)
                    startActivity(intent)
                }; if (rdbtailor.isChecked){
                    val intent = Intent(this, MesurementManagement::class.java)
                    intent.putExtra("KEY_username", username)
                    startActivity(intent)
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show()
                } else{
                    Toast.makeText(this, "Select shop", Toast.LENGTH_SHORT).show()
                }

            } else {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
            }
        }

        registerButton.setOnClickListener {
            navigateToRegistration()
        }
    }


    private fun navigateToRegistration() {
        val intent = Intent(this, Registration::class.java)
        startActivity(intent)
    }


}