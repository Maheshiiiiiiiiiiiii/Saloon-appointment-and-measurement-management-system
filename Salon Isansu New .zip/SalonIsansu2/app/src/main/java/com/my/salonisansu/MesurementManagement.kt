package com.my.salonisansu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast

class MesurementManagement : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mesurement_management)
       val etBust = findViewById<EditText>(R.id.etBust)
        val etWaist = findViewById<EditText>(R.id.etWaist)
        val etHip = findViewById<EditText>(R.id.etHip)
        val btnSaveMeasurements = findViewById<Button>(R.id.btnSaveMeasurements)

        btnSaveMeasurements.setOnClickListener {
            val subject_list: ArrayList<Subject> = ArrayList()
            val subjectList= findViewById<ListView>(R.id.listview32)
            val adapter = Adpater1(this, subject_list)
            subjectList.adapter = adapter

            val bust = etBust.text.toString()
            val waist = etWaist.text.toString()
            val hip = etHip.text.toString()

            if (bust.isNotEmpty() && waist.isNotEmpty() && hip.isNotEmpty()) {
                // Process the measurements
                Toast.makeText(this, "Measurements saved successfully!", Toast.LENGTH_SHORT).show()
                val subject = Subject("1",bust, waist, hip)
                subject_list.add(subject)
            } else {
                Toast.makeText(this, "Please enter all measurements", Toast.LENGTH_SHORT).show()
            }
        }
    }
}