package com.my.salonisansu

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class Registration : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)
       val usernameEditText = findViewById<EditText>(R.id.txtusername)
        val passwordEditText = findViewById<EditText>(R.id.txtpassword)
        val registerButton = findViewById<Button>(R.id.btnregister)
        val db=DBHelper(this,null)


        registerButton.setOnClickListener {
            val username = usernameEditText.text.toString().toLowerCase().trim()
            val password = passwordEditText.text.toString().toLowerCase().trim()

            if (username.isNotEmpty() && password.isNotEmpty()) {

                db.insert1(username, password)
                Toast.makeText(this, "Registration Successful", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }
}
