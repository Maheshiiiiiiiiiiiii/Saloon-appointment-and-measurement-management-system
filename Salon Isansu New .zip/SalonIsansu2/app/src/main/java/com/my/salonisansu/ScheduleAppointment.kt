package com.my.salonisansu

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import android.app.TimePickerDialog
import java.util.*
import kotlin.collections.ArrayList

class ScheduleAppointment : AppCompatActivity() {
    private lateinit var selectedDate: String
    private lateinit var selectedTime: String
    private lateinit var calendar: Calendar
    private var appointmentsCount: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_schedule_appointment)

        val btnSelectDate = findViewById<Button>(R.id.btnSelectDate)
        val btnSelectTime = findViewById<Button>(R.id.btnSelectTime)
        val btnSchedule = findViewById<Button>(R.id.btnSchedule)
        val btnview = findViewById<Button>(R.id.btnview)
        btnSelectDate.setOnClickListener {
            showDatePicker()
        }

        btnSelectTime.setOnClickListener {
            showTimePickerDialog()
        }
        btnview.setOnClickListener {
            val tvSelectedTime = findViewById<TextView>(R.id.tvSelectedTime)
            val tvSelectedDate = findViewById<TextView>(R.id.tvSelectedDate)
            val bust = tvSelectedDate.text.toString()
            val waist = tvSelectedTime.text.toString()

            val subject_list: ArrayList<Subject> = ArrayList()
            val subjectList = findViewById<ListView>(R.id.listview4)
            val adapter = adapter2(this, subject_list)
            subjectList.adapter = adapter
            val subject = Subject("1", bust, waist, "")
            subject_list.add(subject)
        }
        btnSchedule.setOnClickListener {
            val tvSelectedTime = findViewById<TextView>(R.id.tvSelectedTime)
            val tvSelectedDate = findViewById<TextView>(R.id.tvSelectedDate)
            val bust = tvSelectedDate.text.toString()
            val waist = tvSelectedTime.text.toString()

            if (bust.isNotEmpty() && waist.isNotEmpty()) {
                // Check if the selected time slot is available and not blocked by the admin
                if (isTimeSlotAvailable(bust, waist)) {
                    // Check if the appointment limit for the selected date is not exceeded
                    if (isAppointmentLimitNotExceeded(bust)) {
                        // Proceed with scheduling the appointment
                        scheduleAppointment(bust, waist)
                        Toast.makeText(
                            this,
                            "Appointment scheduled successfully!",
                            Toast.LENGTH_SHORT
                        ).show()
                        finish()
                    } else {
                        Toast.makeText(
                            this,
                            "Appointment limit for the selected date has been reached.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        this,
                        "Selected time slot is not available.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                Toast.makeText(this, "Please select a date and time.", Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }

        @SuppressLint("SetTextI18n")
        fun showDatePicker() {
            calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)
            val tvSelectedDate = findViewById<TextView>(R.id.tvSelectedDate)

            val datePicker = DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
                calendar.set(selectedYear, selectedMonth, selectedDay)
                selectedDate =
                    SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(calendar.time)
                tvSelectedDate.text = "Selected Date: $selectedDate"
            }, year, month, day)

            datePicker.datePicker.minDate = System.currentTimeMillis()
            datePicker.show()
        }

        private fun isTimeSlotAvailable(date: String, time: String): Boolean {
            // Check if the selected time slot is available and not blocked by the admin
            return true
        }

        private fun isAppointmentLimitNotExceeded(date: String): Boolean {

            return appointmentsCount < 20
        }

        private fun scheduleAppointment(date: String, time: String) {}


        @SuppressLint("SetTextI18n")
        fun showTimePickerDialog() {
            val currentTime = Calendar.getInstance()
            val hour = currentTime.get(Calendar.HOUR_OF_DAY)
            val minute = currentTime.get(Calendar.MINUTE)
            val tvSelectedTime = findViewById<TextView>(R.id.tvSelectedTime)


            val timePickerDialog = TimePickerDialog(
                this,
                { _, selectedHour, selectedMinute ->
                    val selectedTime = formatTime(selectedHour, selectedMinute)
                    tvSelectedTime.text = "Selected Date: $selectedTime"
                },
                hour,
                minute,
                false
            )
            timePickerDialog.show()
        }

        fun formatTime(hour: Int, minute: Int): String {
            val calendar = Calendar.getInstance()
            calendar.set(Calendar.HOUR_OF_DAY, hour)
            calendar.set(Calendar.MINUTE, minute)

            val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
            return timeFormat.format(calendar.time)
        }
    }

