package com.my.salonisansu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast

class ServiceSelection : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_service_selection)

        val radioGroupServices = findViewById<RadioGroup>(R.id.radioGroupServices)
        val checkBoxCustomization1 = findViewById<CheckBox>(R.id.checkBoxCustomization1)
        val checkBoxCustomization2 = findViewById<CheckBox>(R.id.checkBoxCustomization2)
        val checkBoxCustomization3 = findViewById<CheckBox>(R.id.checkBoxCustomization3)
        // Initialize more CheckBox variables as needed

        val btnConfirm = findViewById<Button>(R.id.btnConfirm)

        btnConfirm.setOnClickListener {
            val selectedService = getSelectedService()
            val selectedCustomizations = getSelectedCustomizations()

            if (selectedService.isNotEmpty()) {
                // Process the selected service
                Toast.makeText(this, "Selected Service: $selectedService", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Please select a service", Toast.LENGTH_SHORT).show()
            }

            if (selectedCustomizations.isNotEmpty()) {
                // Process the selected customizations
                val customizationsText = selectedCustomizations.joinToString(", ")
                Toast.makeText(this, "Selected Customizations: $customizationsText", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun getSelectedService(): String {
        val radioGroupServices = findViewById<RadioGroup>(R.id.radioGroupServices)
        val radioButtonId = radioGroupServices.checkedRadioButtonId
        return findViewById<RadioButton>(radioButtonId)?.text?.toString() ?: ""
    }

    private fun getSelectedCustomizations(): List<String> {
        val checkBoxCustomization1 = findViewById<CheckBox>(R.id.checkBoxCustomization1)
        val checkBoxCustomization2 = findViewById<CheckBox>(R.id.checkBoxCustomization2)
        val checkBoxCustomization3 = findViewById<CheckBox>(R.id.checkBoxCustomization3)
        val selectedCustomizations = mutableListOf<String>()

        if (checkBoxCustomization1.isChecked) {
            selectedCustomizations.add(checkBoxCustomization1.text.toString())
        }
        if (checkBoxCustomization2.isChecked) {
            selectedCustomizations.add(checkBoxCustomization2.text.toString())
        }
        if (checkBoxCustomization3.isChecked) {
            selectedCustomizations.add(checkBoxCustomization3.text.toString())
        }
        // Add more CheckBox conditions as needed

        return selectedCustomizations
    }
}