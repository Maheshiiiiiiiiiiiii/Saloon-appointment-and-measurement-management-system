package com.my.salonisansu

import android.annotation.SuppressLint
import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class adapter2 (private val context: Activity,
private val subjectlist:ArrayList<Subject>

) : ArrayAdapter<Subject>(context, R.layout.card1, subjectlist ){
    @SuppressLint("ViewHolder", "InflateParams", "MissingInflatedId", "SetTextI18n")
    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val subjectItem = context.layoutInflater.inflate(R.layout.card1, null, true)
        val lblTo: TextView = subjectItem.findViewById(R.id.lblbust)
        val lblFromTime: TextView = subjectItem.findViewById(R.id.lblwaist)
        val lblToTime: TextView = subjectItem.findViewById(R.id.lblhip)
        val bust : String = subjectlist[position].getN0()
        val waist: String = subjectlist[position].getFrom()
        val hip : String = subjectlist[position].getTime()

        lblTo.setText(bust).toString()
        lblFromTime.setText(waist).toString()
        lblToTime.setText("").toString()

        return subjectItem
    }
}