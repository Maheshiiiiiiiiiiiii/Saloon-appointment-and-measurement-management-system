package com.my.salonisansu

class Subject (
    private var get_id :String,
    private var getNo:String,
    private var getFrom:String,
    private var getTime:String
) {
    public fun getId():String{
        return get_id
    }
    public fun setId(id:String){ get_id=id
    }

    public fun getN0():String{
        return getNo
    }
    public fun setNO(RouteNo:String){
        getNo=RouteNo
    }
    public fun getFrom():String{
        return getFrom
    }
    public fun setFrom(From: String){
        getFrom=From
    }
    public fun getTime():String{
        return getTime
    }


}